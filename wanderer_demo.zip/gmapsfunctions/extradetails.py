import bs4
import urllib.request
import re

headers = {
    'User-Agent':
    'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36'}


def open_url(event, address_number):
    """
    Function to open event webpage

    Event is the location pulled from Google Places API

    Address_number is the first substring of numbers in a location's address

    """
    google_url = "https://google.com/search?q=" + event + "+" + address_number
    source = urllib.request.Request(google_url, None, headers=headers)
    open_source = urllib.request.urlopen(source).read()
    soup = bs4.BeautifulSoup(open_source, 'html.parser')
    dict_of_location = scrape_results(soup)
    return dict_of_location


def scrape_results(html_soup):
    dict_to_open_url = {}
    try:
        op_hours = get_op_hours_open(
            html_soup.find_all("span", class_="_Map")[0].string)
        dict_to_open_url.update({'op_hours':op_hours})
    except (UnicodeEncodeError, IndexError) as e:
        print("Happened while scrapping op_hours in scrape_results" + format(e))
    try:
        avg_time = get_avg_wait_time(
            html_soup.find_all("div", class_="_B1k")[0].b.string)
        dict_to_open_url.update({'avg_time':avg_time})
    except:
        print("No average wait time")
    try:
        desc_text = get_description_text(
            html_soup.find_all("span", class_="_ZCm")[0].string)
        dict_to_open_url.update({'desc_text':desc_text})
    except:
        print('No Descrption from scrapping')
    try:
        phone_num = get_phone_number(html_soup.find_all(
            "span", class_="_Xbe _ZWk kno-fv")[0].string)
        dict_to_open_url.update({'phone_num':phone_num})
    except Exception as e:
        print("Phone number: " + e)

    return dict_to_open_url


def get_op_hours_open(hours_open):
   # print(hours_open)
    return hours_open


def get_avg_wait_time(waiting_time):
    hyphen = 0
    try:
        hyphen = waiting_time.index('–')
    except:
        print("Est. time so short did not need a hyphen")
    if hyphen == 0:
        first_estimate = waiting_time[:2]
        estimate_wait = {'first_estimate': first_estimate}
    else:
        first_estimate = waiting_time[:hyphen]
        second_estimate = waiting_time[hyphen + 1:6]
        estimate_wait = {'first_estimate': first_estimate,
            'second_estimate': second_estimate}
    return estimate_wait


def get_description_text(desc_text):
    # print(desc_text)
    return desc_text


def get_phone_number(phone_num):
   # print(phone_num)
    return phone_num.string