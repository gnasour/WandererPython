import googlemaps
from datetime import datetime
apikey = "AIzaSyDwtd512Z3TfsQxNd-NNgsIILBaNrUv_xs"
gmaps = googlemaps.Client(key=apikey)


# print(geocode_results[0]['geometry']['location']['lat'],geocode_results[0]['geometry']['location']['lng'])
def place_check(query: str, location: str, radius: int, min_price: int = 0,
                max_price: int = 4, open_now: bool = True, types: str = None, page_token: str = None):
    """Return list of places for user to use"""
    geocode_results = gmaps.geocode(location)
    location_coords = (geocode_results[0]['geometry']['location']['lat'], geocode_results[0]['geometry']['location']['lng'])
    parse_gmaps_dict_info = gmaps.places(query, location_coords, radius,)
    establishment_name = []
    address = []
    tags = []
    
    for i in range(len(parse_gmaps_dict_info['results'])):
        establishment_name.append(parse_gmaps_dict_info['results'][i]['name'])
        address.append(
            parse_gmaps_dict_info['results'][i]['formatted_address'])
        tags.append(parse_gmaps_dict_info['results'][i]['types'])
        

    places_list=[establishment_name[:5], address[:5], tags[:5]]
    return places_list

#p = place_check(input("Enter desired activity\n"), input("Enter Address (Street# & Name)/(City)/(State)\n"), int(input("Radius to bias in meters\n")))
#p=place_check("food", "16744 Devonshire St, Granada Hills, CA", int(500))
#print(p)
