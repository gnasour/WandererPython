x = []
y = x.string
print(y)