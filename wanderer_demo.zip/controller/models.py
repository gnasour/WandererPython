from django.db import models
import datetime
from django.utils import timezone


class Person(models.Model):
    first_name = models.CharField(max_length=20, default ="")
    last_name = models.CharField(max_length=20, default ="")
    email = models.CharField(max_length=100, default ="", unique=True)
    username = models.CharField(max_length=20, primary_key=True, null = False, default="")
    password = models.CharField(max_length=35, default ="")
    address = models.CharField(max_length=50, default ="")
    age = models.PositiveIntegerField(default=0)
    gender = models.CharField(max_length=7, default ="")
    date_joined = models.DateField(default = timezone.now())
    interest_list = models.TextField(null = True)
    

    def full_name(self):
        "Return the full name of the person"
        return '%s %s' % (self.first_name, self.last_name)

    def __str__(self):
        return self.username

    class Meta:
        ordering = ('username',)


class Event(models.Model):
    #DB relation to link people and an event
    peopleJoining = models.ManyToManyField(Person, through="EventPeople")
    #Name of the event
    event_text = models.CharField(max_length=50,default ="")
    #Hours of operation measured in hours
    op_hours_open = models.CharField(max_length=20,default="")
    #Address of event
    address = models.CharField(max_length=200, primary_key = True, null=False)
    #Simple description of the event
    description_text = models.CharField(max_length=1000, default="No Descrption")
    #Average time spent at a location, measured in minutes
    avg_time_spent = models.PositiveIntegerField(default=0)
    #Date added into DB
    add_date = models.DateTimeField("Date Added")
    #Check if location is currently open
    is_open = models.BooleanField(default=True)
    #Phone number of the event
    phone_number = models.CharField(max_length=15, default ="")

    def __str__(self):
        return self.event_text

    class Meta:
        ordering = ('event_text',)

    


class EventPeople(models.Model):
    person = models.ForeignKey(Person, on_delete=models.CASCADE)
    event = models.ForeignKey(Event, on_delete=models.CASCADE)
    date_joined = models.DateTimeField()

    def __str__(self):
        return '%s' % (self.event.event_text)

    def joined(self):
        return date_joined

    class Meta:
        ordering = ('date_joined',)
