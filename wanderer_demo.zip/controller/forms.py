from django import forms
from .models import  Person
from django.forms import ModelForm


class PersonForm(ModelForm):
    class Meta:
        model = Person
        fields = ['first_name', 'last_name', 'age',]

    def clean(self):
        cleaned_data = super(PersonForm, self).clean()
        first_name = cleaned_data.get('first_name')
        last_name = cleaned_data.get('last_name')
        age = cleaned_data.get('age')
        p