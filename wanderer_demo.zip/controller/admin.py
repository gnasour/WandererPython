from django.contrib import admin


from .models import Event, Person, EventPeople


class EventPeopleInline(admin.StackedInline):
    model = EventPeople
    
class PersonAdmin(admin.ModelAdmin):
    fields=['first_name','last_name','age','username', 'password','address','interest_list']
    inlines=[EventPeopleInline]

admin.site.register(Person, PersonAdmin)
admin.site.register(Event)
    

