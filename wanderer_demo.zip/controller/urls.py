from django.conf.urls import include,url

from . import views

app_name = 'controller'

settings_patterns=[
                url(r'^settings/$',views.settings, name='setting'),
                url(r'^delete/$', views.delete_view, name='delete_view'),
                url(r'^change_password/$', views.change_password, name='change_password'),
                url(r'^change_interests/$', views.change_interests, name='change_interests'),
                ]

user_patterns =[url(r'^(?P<un>\w+)/$',views.ProfileView, name ='profile'),
                url(r'^(?P<username>[\w|\W]+)/linkEvent/$', views.linkEvent, name='link'),
                url(r'^event/(?P<eventName>[\w|\W]+)/$', views.detailed_event, name='detailedevent'),
                url(r'^(?P<username>\w+)/', include(settings_patterns)),
               ]


urlpatterns = [url(r'^$', views.index, name='index'),
               url(r'^user/', include(user_patterns)),
               url(r'^googleevents/$', views.googleevents, name='googleevents'),
               url(r'addgoogleevents/$', views.add_google_events, name='add_google_events'),
               url(r'^added/$', views.add_person, name = 'add_person'),
               url(r'^delete/process/$', views.delete_process, name='delete_process'),
               url(r'^signup/$', views.sign_up, name='sign_up'),
               url(r'^landing/$', views.landing, name='landing'),
               url(r'^check/$', views.check_person, name='check_person'),
               url(r'^logout/$', views.logout, name='logout')
               ]
