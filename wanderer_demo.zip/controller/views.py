from django.shortcuts import render, get_object_or_404, render_to_response
from django.http import HttpResponse, HttpResponseRedirect
from .models import Person, Event, EventPeople
from django.views import generic
from django.template import loader
from django.utils import timezone
from django.urls import reverse
from gmapsfunctions.gmapplaces import place_check
from gmapsfunctions.extradetails import open_url
from .forms import PersonForm
from django.contrib import messages, auth
from django.db import IntegrityError
import json
jsonDec = json.decoder.JSONDecoder()


def index(request):
    all_users = Person.objects.all()
    form = PersonForm()

    return render(request, 'controller/index.html', {'form': form, 'users': all_users})

def landing(request):
    return render(request, 'controller/landing.html', None)


def sign_up(request):
    return render(request, 'controller/signup.html', None)

def logout(request):
    auth.logout(request)
    return HttpResponseRedirect(reverse('controller:sign_up'))


def check_person(request):
    wrong_credentials = False
    try:
        account_username = Person.objects.get(pk = request.POST['login_username'])
    except:
        wrong_credentials = True
        template = loader.get_template('controller/signup.html')
        context = {'error': wrong_credentials}
        return HttpResponse(template.render(context, request))
    try:
        if account_username.password == request.POST.get('login_password'):
            return HttpResponseRedirect(reverse('controller:profile', args=([account_username])))
    except:
        messages.info(request, 'Wrong Username/Password')
        return render(request, 'controller:sign_up',{
            'error_message': 'Wrong password'
    })
    else:
        wrong_credentials = True
        template = loader.get_template('controller/signup.html')
        context = {'error': wrong_credentials}
        return HttpResponse(template.render(context, request))



def add_person(request):
    firstname = request.POST['firstname']
    lastname = request.POST['lastname']
    email_input = request.POST['email']
    username_input = request.POST['username']
    password_input = request.POST['password']
    address_input = request.POST['address']
    age_input = request.POST['age']
    gender_input = request.POST['gender']
    interest_list_input = json.dumps(request.POST.getlist('interest[]'))
    Person.objects.create(first_name=firstname,
                          last_name=lastname, email=email_input, username=username_input,
                          password=password_input, address=address_input, age=age_input, gender=gender_input, interest_list=interest_list_input)
    return HttpResponseRedirect(reverse('controller:profile', args=([username_input])))


def ProfileView(request, un):
    request.session['username'] = un
    getPerson = Person.objects.get(username=un)
    event_loader = Event.objects.all()
    user_city_position = getPerson.address.index(',')
    user_city = getPerson.address[user_city_position+2:]
    template = loader.get_template('controller/homepage.html')
    time = None
    if 'time' in request.session:
        time = request.session['time']
    context = {'user': getPerson, 'events': event_loader,'user_city':user_city, 'time':time}
    return HttpResponse(template.render(context, request))


def store_events(request,):
    pass


def linkEvent(request, username):
    user = get_object_or_404(Person, pk=username)
    try:
        selected_event = Event.objects.get(
            event_text=request.POST.get('event'))
    except:
        return HttpResponse("Event could not be pulled")
    else:
        EventPeople.objects.create(
            person=user, event=selected_event, date_joined=timezone.now())
        return HttpResponseRedirect(reverse('controller:profile', args=([user.username])))


def detailed_event(request, eventName):
    #Scrape extra details from Google
    #By passing address and event from Event model
    #To Extra Details Function
    #Update the event before viewing it

    #Remove spaces and input %20 instead for url to work
    eventName = eventName.replace("%20", " ")

    #Get the event object from DB
    events = get_object_or_404(Event, pk=eventName)

    #Location space in the address string and extract the address street number
    space_location = events.address.index(" ")
    event_address = events.address[:space_location]

    #Dict of scrapped info
    update_event_dict = open_url(events.event_text.replace(' ','%20'), event_address)

    if 'op_hours' in update_event_dict:
        events.op_hours_open = update_event_dict['op_hours']
    if 'desc_text' in update_event_dict:
        events.description_text = update_event_dict['desc_text']
    first_estimate = 0
    second_estimate = 0
    if 'avg_time' in update_event_dict:
        if 'first_estimate' in update_event_dict['avg_time'] and update_event_dict['avg_time']['first_estimate'] != None:
            first_estimate = int(update_event_dict['avg_time']['first_estimate'])
        if 'second_estimate' in update_event_dict['avg_time'] and update_event_dict['avg_time']['second_estimate'] != None:
            second_estimate = int(update_event_dict['avg_time']['second_estimate'])
    events.avg_time_spent = (first_estimate + second_estimate)/2
    if 'phone_num' in update_event_dict:
        events.phone_number = update_event_dict['phone_num']
    events.save()
    template = loader.get_template('controller/DetailEvent.html')
    context = {"event": events}
    return HttpResponse(template.render(context, request))


def googleevents(request,):
    try:
        desired_event = request.POST['desired_event']
    except:
        return HttpResponse("Could not get event")
    else:
        p = place_check(
            desired_event, "16750 Devonshire St, Granada Hills, CA", int(500))
        for iterate_in_google_list in range(len(p[0])):
            Event.objects.create(
                event_text=p[0][iterate_in_google_list], address=p[1][iterate_in_google_list], add_date=timezone.now())
        template = loader.get_template('controller/googleevent.html')
        context = {"places": p[0], "address": p[1], "tags": p[2], }
        return HttpResponse(template.render(context, request))


def add_google_events(request,):
    #This is the user's username
    users = request.session['username']
    #This is the user object
    user = get_object_or_404(Person,pk = users)
    try:
        desired_event_list = jsonDec.decode(user.interest_list)
        desired_event = ""
        for events in desired_event_list:
            desired_event += desired_event_list.pop() + " and "
        if 'use_my_address' in request.POST:
            address = user.address
        else:
            address = request.POST['address_input']
        radius = int(request.POST.get('radius_input'))
        if not ('time' in request.session): 
            request.session['time'] = request.POST['time_input']
        p = place_check(desired_event, address, radius)
        for iterate_in_google_list in range(len(p[0])):
            Event.objects.create(
                event_text=p[0][iterate_in_google_list], address=p[1][iterate_in_google_list], add_date=timezone.now())
        return HttpResponseRedirect(reverse('controller:profile', args=([users])))
    except IntegrityError as e:
        print("Unique constraint failed in add_google_events function" + format(e))
        return HttpResponseRedirect(reverse('controller:profile', args=([users])))
    except Exception as e_2:
        print(e_2)
        return render(request, 'controller/create_event.html')


def settings(request, username):
    return render(request, 'controller/settings.html', {'user':username})
        
def delete_view(request, username):
    if 'submit_deleteyes' in request.POST:
        try:
            person_to_delete = get_object_or_404(Person, pk = username)
        except Exception as e:
            print('Error in pulling someone to delete' + format(e))
            return render(request, 'controller/delete.html')
        else:
            person_to_delete.delete()
            return logout(request)
    elif 'submit_deleteno' in request.POST:
        return HttpResponseRedirect(reverse('controller:profile', args=([username])))
    else:
        return render(request, 'controller/delete_account.html', {'user':username})


def change_password(request, username):
    if request.method == 'POST':
        try:
            user_to_change_pw = get_object_or_404(Person, pk = username)
            if request.POST['password'] == request.POST['repassword']:
                user_to_change_pw.password = request.POST['password']
                user_to_change_pw.save()
            else:
                 return render(request, 'controller/change_password.html', {'user':username})
        except:
            print("Could not retrieve object in change_password")
        else:
            return HttpResponseRedirect(reverse('controller:profile', args=([username])))
    else:
        return render(request, 'controller/change_password.html', {'user':username})



def change_interests(request, username):
    if request.method == 'POST':
        try:
            user_to_change_interest = get_object_or_404(Person, pk = username)
            if 'interest' in request.POST:
                new_interests = json.dumps(request.POST.getlist('interest'))
                user_to_change_interest.interest_list=new_interests
                user_to_change_interest.save()
            else:
                 return render(request, 'controller/change_interest.html', {'user':username})
        except:
            print("Could not retrieve object in change_password")
        else:
            return HttpResponseRedirect(reverse('controller:profile', args=([username])))
    else:
        return render(request, 'controller/change_interest.html', {'user':username})



def delete_process(request):
    try:
        delete_pk = request.POST['delete_name']
        p = get_object_or_404(Person, pk=delete_pk)
    except:
        HttpResponse(
            "Bruh something went wrong on deletion: Could not get name")
    else:
        p.delete()

    return HttpResponseRedirect(reverse('controller:index', args=()))


